let btn = document.querySelector('.nav-btn');

btn.addEventListener('click',() =>{
    history.back();
})